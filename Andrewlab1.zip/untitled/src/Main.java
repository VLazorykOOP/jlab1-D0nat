import java.util.Scanner;

public class Main {
    public Main() {
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        T1 task1 = new T1();
        T2 task2 = new T2();
        T3 task3 = new T3();
        T4 task4 = new T4();

        while(true) {
            while(true) {
                System.out.println("------------------------------");
                System.out.println("What task do you want to execute?");
                System.out.println("1. Task 1");
                System.out.println("2. Task 2");
                System.out.println("3. Task 3");
                System.out.println("4. Task 4");
                System.out.println("5. Exit");


                int opt=0;
                String input;
                do{
                    System.out.print("Choose an option: ");
                    input = scanner.next();
                    if (!input.matches("\\d+")) {
                        System.out.println("INT");
                        continue;
                    }
                    opt=Integer.parseInt(input);
                    break;
                }while(true);



                System.out.print("\n");
                switch (opt) {
                    case 1:
                        task1.t1();
                        break;
                    case 2:
                        task2.t2();
                        break;
                    case 3:
                        task3.t3();
                        break;
                    case 4:
                        task4.t4();
                        break;
                    case 5:
                        System.exit(0);
                    default:
                        System.out.println("There is no option for this number \n");
                }
            }
        }
    }
}
