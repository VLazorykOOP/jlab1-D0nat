import java.util.Scanner;
import java.util.Arrays;
public class T4 {
    public T4() {
    }

    public void t4() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Введіть рядок: ");
        String input = scanner.nextLine();

        String[] words = input.split("[^a-z]");
        Arrays.sort(words);


        for (int i = 0; i < words.length; i++) {
            if (!words[i].isEmpty() && words[i].charAt(0) >= 'a' && words[i].charAt(0) <= 'z') {
                System.out.println(words[i]);
            }
        }
    }
}
