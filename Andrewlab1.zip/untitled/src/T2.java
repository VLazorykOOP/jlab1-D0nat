import java.util.Scanner;
public class T2 {
    public T2() {
    }

    public void t2() {
        Scanner scan = new Scanner(System.in);
        System.out.println(" Задано масив чисел A(n), n<500\n" +
                ". Розробити програму, яка обчислює суму всіх чисел, які \n" +
                "знаходяться між першим і останнім від’ємними елементами цього масиву і вказує цей \n" +
                "діапазон. Якщо від’ємних чисел немає або є тільки одно, то виводить повідомлення про це.\n");
        int n=0;
        String input1;
        do {
            System.out.println("Input n");
            input1 = scan.nextLine();
            String[] inputs = input1.split(" ");
            if (!inputs[0].matches("\\d+")) {
                System.out.println("INT POSITIVE");
                continue;

            }
            n = Integer.parseInt(inputs[0]);

            if (n>500){
                System.out.println("no 500+");
            }
            else {
                n = Integer.parseInt(inputs[0]);
                break;
            }
        } while (true);
        System.out.println("Input array");
        String input;
        int[] array = new int[n];
        for (int i = 0; i < n; i++) {
            System.out.print("array[" + i + "]= ");



            do {

                input = scan.nextLine();
                String[] inputs = input.split(" ");
                if (!inputs[0].matches("-?\\d+")) {
                    System.out.println("INT");
                    continue;
                }
                array[i] = Integer.parseInt(inputs[0]);
                break;
            } while (true);
        }
        System.out.print("Your array: [");

        for (int i = 0; i < n-1; i++) {
            System.out.print(array[i] +", ");
        }
        System.out.print(array[n-1]+"] ");

        System.out.println();
        int firstNeg = -1, lastNeg = -1;
        for (int i = 0; i < array.length; i++) {
            if (array[i] < 0) {
                if (firstNeg == -1) {
                    firstNeg = i;
                }
                lastNeg = i;
            }
        }
        if (firstNeg == -1 || firstNeg == lastNeg) {
            System.out.println("no negative or only one");
            return;
        }
        int sum = 0;
        for (int i = firstNeg + 1; i < lastNeg; i++) {
            sum += array[i];
        }
        System.out.println("Suma: " + sum);
    }
}