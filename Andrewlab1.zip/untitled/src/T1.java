import java.util.Scanner;

public class T1 {
    public T1() {
    }

    public void t1() {
        Scanner scan = new Scanner(System.in);
        System.out.println("За введеними значеннями обчислити та вивести на екран значення виразу. Обчислення \n" +
                "виконати у трьох варіантах: 1) вхідні дані дійсного типу, результат – дійсного; 2) вхідні дані \n" +
                "цілого типу, результат – дійсного; 3) вхідні дані дійсного типу, результат – цілого ");

        while(true) {
            Variants:
            while(true) {
                System.out.println("------------------------------");
                System.out.println("What type of number should be used?");
                System.out.println("1. Int");
                System.out.println("2. Double");
                System.out.println("3. Leave");
                int opt=0;
                String input1;
                do {

                    input1 = scan.nextLine();
                    String[] inputs = input1.split(" ");
                    if (!inputs[0].matches("\\d+")) {
                        System.out.println("INT");
                        continue;
                    }
                    opt = Integer.parseInt(inputs[0]);
                    break;
                } while (true);

                int opt2 = 0;
                double md;
                double nd;
                int resint;
                double resd;
                switch (opt) {
                    case 1:
                        while(true) {
                            if (opt2 == 3) {
                                continue Variants;
                            }

                            System.out.println("------------------------------");
                            System.out.println("What type do you want result to be?");
                            System.out.println("1. Int");
                            System.out.println("2. Double");
                            System.out.println("3. Back");
                            String input;
                            do {

                                input = scan.nextLine();
                                String[] inputs = input.split(" ");
                                if (!inputs[0].matches("\\d+")) {
                                    System.out.println("INT");
                                    continue;
                                }
                                opt2 = Integer.parseInt(inputs[0]);
                                break;
                            } while (true);

                            int mint;
                            int nint;
                            switch (opt2) {
                                case 1:
                                    System.out.println("Enter m: ");
                                    mint = scan.nextInt();
                                    System.out.println("Enter n: ");
                                    nint = scan.nextInt();
                                    resint = (((nint+1)*(mint-4)+nint*mint-nint*nint*nint*nint+mint*mint*mint)/((mint+2)*(mint+2)));
                                    System.out.println("Result: " + resint);
                                    break;
                                case 2:
                                    System.out.println("Enter m: ");
                                    mint = scan.nextInt();
                                    System.out.println("Enter n: ");
                                    nint = scan.nextInt();
                                    md = (double)mint;
                                    nd = (double)nint;
                                    resd = (((nd+1)*(md-4)+nd*md-nd*nd*nd*nd+md*md*md)/((md+2)*(md+2)));
                                    System.out.println("Result is: " + resd);
                                    break;
                                default:
                                    System.out.println("There is no option for this number");
                            }
                        }
                    case 2:
                        while(opt2 != 3) {
                            System.out.println("------------------------------");
                            System.out.println("What type do you want result to be?");
                            System.out.println("1. Int");
                            System.out.println("2. Double");
                            System.out.println("3. Back");
                            String input2;
                            do {

                                input2 = scan.nextLine();
                                String[] inputs = input2.split(" ");
                                if (!inputs[0].matches("\\d+")) {
                                    System.out.println("INT");
                                    continue;
                                }
                                opt2 = Integer.parseInt(inputs[0]);
                                break;
                            } while (true);

                            switch (opt2) {
                                case 1:
                                    System.out.println("Enter m: ");
                                    md = scan.nextDouble();
                                    System.out.println("Enter n: ");
                                    nd = scan.nextDouble();
                                    resint = (int)(((nd+1)*(md-4)+nd*md-nd*nd*nd*nd+md*md*md)/((md+2)*(md+2)));
                                    System.out.println("Result is: " + resint);
                                    break;
                                case 2:
                                    System.out.println("Enter m: ");
                                    md = scan.nextDouble();
                                    System.out.println("Enter n: ");
                                    nd = scan.nextDouble();
                                    resd = (((nd+1)*(md-4)+nd*md-nd*nd*nd*nd+md*md*md)/((md+2)*(md+2)));
                                    System.out.println("Result is: " + resd);
                                    break;
                                default:
                                    System.out.println("There is no option for this number");
                            }
                        }
                        break;
                    case 3:
                        System.exit(0);
                    default:
                        System.out.println("There is no option for this number");
                }
            }
        }
    }
}