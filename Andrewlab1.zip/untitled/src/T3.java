import java.util.Scanner;
public class T3 {
    public T3() {
    }

    public void t3() {
        System.out.println(" Задана цілочислова матриця  A(n,n), n <=15 \n" +
                "Розробити програму, яка знаходить і друкує \n" +
                "номери тих рядків, у яких всі елементи однакові, і номери тих стовпчиків, всі елементи в яких парні \n");
        Scanner scanner = new Scanner(System.in);


        int n = 16;
        while (n > 15) {
            System.out.println("Input n= SIZE of matrix[n;n] <= 15");
            String input3;
            do {

                input3 = scanner.nextLine();
                String[] inputs = input3.split(" ");
                if (!inputs[0].matches("\\d+")) {
                    System.out.println("INT");
                    continue;
                }
                if (n<0){
                    System.out.println("no - pls");
                }
                n = Integer.parseInt(inputs[0]);
                break;
            } while (true);

            int[][] A = new int[n][n];
            System.out.println("Enter elements of matrix A: ");


            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    System.out.print("matrix[" + i + "]" + "[" + j + "]=");

                    String input2;
                    do {

                        input2 = scanner.nextLine();
                        String[] inputs = input2.split(" ");
                        if (!inputs[0].matches("-?\\d+")) {
                            System.out.println("INT");
                            continue;
                        }
                        A[i][j] = Integer.parseInt(inputs[0]);
                        break;
                    } while (true);

                }
            }
            System.out.println("Elements of matrix A are: ");
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    System.out.print(A[i][j] + " ");
                }
                System.out.println();
            }

            System.out.println("Rows with same elements:");
            for (int i = 0; i < n; i++) {
                boolean same = true;
                for (int j = 1; j < n; j++) {
                    if (A[i][j] != A[i][0]) {
                        same = false;
                        break;
                    }
                }
                if (same) {
                    System.out.print("Row " + (i + 1) + ": ");
                    for (int j = 0; j < n; j++) {
                        System.out.print(A[i][j] + " ");
                    }
                    System.out.println();
                }
            }


            System.out.println("Columns with even elements:");
            for (int j = 0; j < n; j++) {
                boolean even = true;
                for (int i = 0; i < n; i++) {
                    if (A[i][j] % 2 != 0) {
                        even = false;
                        break;
                    }
                }
                if (even) {
                    System.out.print("Column " + (j + 1) + ": ");
                    for (int i = 0; i < n; i++) {
                        System.out.print(A[i][j] + " ");
                    }
                    System.out.println();
                }
            }

        }
    }
}
